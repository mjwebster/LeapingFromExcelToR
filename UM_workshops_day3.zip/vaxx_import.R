#data: kindergarten vaccination rates from the 2017-18 schoolyear
#includes all public and private schools serving kindergartners
#source: Minnesota Department of Health
# see record layout in the /data/ directory
#we'll pair this with school data from the Minnesota Department of Education


#things we're going to learn today:
# appending data frames
# joining data frames
# using case_when to populate new columns
# create an RMarkdown page and knit it to HTML
# how to link a script and RMarkdown page together
# how to make HTML page look a little nicer

#We'll continue practicing:
# analyzing data with dplyr
# making basic charts with ggplot
# importing csv and Excel files
# using mutate to create new columns


#note: Much of the code we'll use is written for you below. 
# sections where it says "YOUR TURN" are where you will need to write your own code



# LOAD LIBRARIES ----------------------------------------------------------


library(readr) 
library(dplyr)
library(ggplot2) #making charts
library(janitor) #use this for doing crosstabs
library(knitr) #needed for making tables in markdown page
library(htmltools)#this is needed for Rstudio to display kable and other html code
library(rmarkdown)
library(kableExtra)
library(ggthemes)
library(readxl) #for importing Excel files
library(scales) #needed for the percent_format on the ggplot
options(scipen=999) #this prevents results from displaying as scientific notation



# IMPORTING -------------------------------------------------------------


#import from Excel
#syntax:  df <- read_excel("./data/filename.xlsx", sheet="Sheet1", range="A1:Z500") %>% clean_names()


kvaxx <-  read_excel("./data/Kindergarten_1718.xlsx", sheet="KINDERGARTEN_1718_COPY") %>% clean_names()



#YOUR TURN
#Look at the structure of the data we imported. Use str() function





#import no response data from csv
#syntax:  df <-  read_csv("./data/filename.csv") %>% clean_names()
#syntax with column formats:  df <-  read_csv("./data/filename.csv", col_types=cols(.default="c")) %>% clean_names()

noresponse <-  read_csv("./data/noresponse_kind_1718.csv", col_types=cols(.default="c")) %>% clean_names()



#YOUR TURN
#review the data
#use head() to look at the top of the noresponse dataframe






# APPENDING DATA FRAMES ------------------------------------------------------

#append no responses to the kindergarten file



#YOUR TURN
#first let's see how well the column names line up. 
#Use names() function on both data frames






#Notice that the noresponse file has a "school_id"
#in the kvaxx file, those numbers are there, but stored in 3 separate fields
#We need to put them together into one field so we can match it to other data
#we'll use mutate to add a new column
#  the paste() function is part of Base R; it's a way to string things together

kvaxx <-  kvaxx %>% 
  mutate(school_id= paste(district_num, school_type, school_num, sep="-"))


#here's syntax for appending rows to another file
#the file named first is where the rows from the other file will end up
#note that here we are overwriting the existing dataframe
#we'll use a function from dplyr  called bind_rows()

kvaxx <-  bind_rows(kvaxx, noresponse)



# REVIEW WHAT WE HAVE -----------------------------------------------------


#Review our vaccination data
#what can we say from it?
#what questions would we like to ask?



#Let's bring in another file that will help us answer those questions
#use read_csv() function to import school_list. Set columns to character
#and clean_names()
#YOUR TURN







# JOINING DATA FRAMES -----------------------------------------------------

#Now we need to JOIN the school_list to the kvaxx data frame. In other words, we'll add new rows
#Note that the school_list file has far more rows than kvaxx. Any idea why?

#Joining two files together requires having at least one common field. What is that here?

#YOUR TURN
#Use names() function to look at column names of both data frames






#Syntax for joining (see R cheat sheet for more details)
#left_join means we'll keep all the rows from the 1st table

kvaxx2 <- left_join(kvaxx,
                    school_list,
                    by=c("school_id"="school_id"))

#Acckk! we added all the fields from school_list, but don't want them all. 
#we can limit what comes over, using dplyr

kvaxx2 <- left_join(kvaxx, 
                    school_list %>% select(school_id, county, schooltype),
                    by=c("school_id"="school_id"))


# limit to MMR ------------------------------------------------------------


#Let's winnow down to just MMR so we can focus our analysis a bit
#we'll use names() function to see which fields we want to put in a new dataframe
names(kvaxx2)

#note how we're also going to rename a field on the fly
k_mmr <-  kvaxx2 %>%
  select(school_id, county, schooltype, disname, schname, enroll, complete_mmr,
                                complete_pert_mmr, inprogress_mmr, inprogress_pert_mmr, co_mmr, co_pert_mmr,
                                me_mmr, me_pert_mmr, 
         district_type=school_type)  #this last one renames the school_type field on the fly



# data cleanup ------------------------------------------------------------


#what problems do we need to deal with?



#YOUR TURN
#Let's look at the enroll field
#use dplyr to summarize the enroll field
#arrange descending






#let's create a new field and populate it depending on what's in the old one
#this uses case_when() function from dplyr
#https://dplyr.tidyverse.org/reference/case_when.html


k_mmr <-  k_mmr %>%  
  mutate(enroll_new = case_when(enroll=='Enrollment < 5' ~ 0, 
                                is.na(enroll) ~ 0,
                                TRUE ~ as.double(enroll)))


#Let's look at school type

k_mmr %>% count(schooltype)

#How about we clean that up, and a little extra in there -- identifying charter schools
#MDE identifies charter schools with the district type="07"


#YOUR TURN
#Use case_when to populate a new field called "schooltyp2" that 
#says "charter" for ones where the district_type=="07", 
#says "unknown" for those where schooltype is null   -- is.na(schooltype)
#and transfers the contents of the schooltype field for all others






#YOUR TURN
#Let's see how that looks. use count() to see what's in the schooltype2 field






#Another nice thing to have would be a single column indicating if a school 
#doesn't have a high enough vaccination rate
#essentially we're going to put our data into buckets or groups, which will make our analysis easier
#health experts say a "community" needs 90-95% vaccination rate to ensure "herd immunity"
#so we'll say that anything below 90% lacks immunity

k_mmr <- k_mmr %>%  
  mutate(mmr_pocket = case_when(complete_pert_mmr>=.895 ~ 'sufficient',
                                complete_pert_mmr>=0 & complete_pert_mmr<.895 ~ 'insufficient',
                                enroll=='Enrollment < 5' ~ 'Enroll<5',
                                is.na(complete_pert_mmr) ~ 'failed to report',
                                TRUE ~ 'unk'))


#open the RMarkdown file called "vaxx.Rmd"
